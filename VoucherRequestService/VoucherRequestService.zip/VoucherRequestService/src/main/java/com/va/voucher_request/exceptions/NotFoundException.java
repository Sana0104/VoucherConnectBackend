package com.va.voucher_request.exceptions;


public class NotFoundException extends Exception{

	public NotFoundException(String msg) {
		super(msg);
	}
}
