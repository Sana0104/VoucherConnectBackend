package com.va.voucher_request.exceptions;

public class VoucherIsAlreadyAssignedException extends Exception {
	
	public VoucherIsAlreadyAssignedException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	public VoucherIsAlreadyAssignedException() {
		// TODO Auto-generated constructor stub
	}
}
