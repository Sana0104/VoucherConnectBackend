package com.va.voucher_request.exceptions;

public class ResourceNotFoundException extends Exception {

	public ResourceNotFoundException(String msg)
	{
		super(msg);
	}
}
