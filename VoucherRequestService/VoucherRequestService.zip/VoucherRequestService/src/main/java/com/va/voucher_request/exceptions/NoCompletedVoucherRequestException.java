package com.va.voucher_request.exceptions;

public class NoCompletedVoucherRequestException extends Exception{

	public NoCompletedVoucherRequestException() {
	}
	
	public NoCompletedVoucherRequestException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}
	
}
