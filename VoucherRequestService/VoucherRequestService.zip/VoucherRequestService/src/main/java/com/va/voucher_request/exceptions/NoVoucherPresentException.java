package com.va.voucher_request.exceptions;

public class NoVoucherPresentException extends Exception {
	public NoVoucherPresentException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	public NoVoucherPresentException() {
		// TODO Auto-generated constructor stub
	}
}
