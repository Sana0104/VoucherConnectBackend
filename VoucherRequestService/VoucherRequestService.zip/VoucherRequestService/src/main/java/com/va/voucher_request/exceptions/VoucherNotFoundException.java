package com.va.voucher_request.exceptions;

public class VoucherNotFoundException extends Exception {
	
	public VoucherNotFoundException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	public VoucherNotFoundException() {
		// TODO Auto-generated constructor stub
	}
}
