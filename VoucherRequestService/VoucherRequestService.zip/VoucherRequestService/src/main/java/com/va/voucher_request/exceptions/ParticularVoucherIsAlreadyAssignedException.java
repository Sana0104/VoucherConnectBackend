package com.va.voucher_request.exceptions;

public class ParticularVoucherIsAlreadyAssignedException extends Exception {
	public ParticularVoucherIsAlreadyAssignedException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	public ParticularVoucherIsAlreadyAssignedException() {
		// TODO Auto-generated constructor stub
	}
	
}
