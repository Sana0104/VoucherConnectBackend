package com.va.voucher_request.exceptions;

public class ResourceAlreadyExistException extends Exception {
	public ResourceAlreadyExistException(String msg)
	{
		super(msg);
	}

}
