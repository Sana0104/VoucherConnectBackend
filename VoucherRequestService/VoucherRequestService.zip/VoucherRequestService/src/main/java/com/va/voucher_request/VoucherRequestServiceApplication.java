package com.va.voucher_request;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoucherRequestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoucherRequestServiceApplication.class, args);
	}
	

}
